package com.example.leaderboard.window;

public enum TimeWindowType {
    DAILY, WEEKLY, MONTHLY
}
