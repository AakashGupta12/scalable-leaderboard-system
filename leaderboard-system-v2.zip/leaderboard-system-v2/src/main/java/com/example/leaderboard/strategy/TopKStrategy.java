package com.example.leaderboard.strategy;

import com.example.leaderboard.core.LeaderboardEntry;
import java.util.List;

public interface TopKStrategy {
    List<LeaderboardEntry> topK(String key, int k);
}
