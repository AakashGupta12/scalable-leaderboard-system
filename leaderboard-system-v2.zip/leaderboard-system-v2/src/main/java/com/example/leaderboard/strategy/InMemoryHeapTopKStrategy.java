package com.example.leaderboard.strategy;


import com.example.leaderboard.core.LeaderboardEntry;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Component("heapTopK")
public class InMemoryHeapTopKStrategy implements TopKStrategy {

    private final Map<String, Map<Long, Long>> data = new ConcurrentHashMap<>();

    @Override
    public List<LeaderboardEntry> topK(String key, int k) {
        Map<Long, Long> scores = data.getOrDefault(key, Map.of());

        PriorityQueue<LeaderboardEntry> minHeap = new PriorityQueue<>(Comparator.comparingLong(LeaderboardEntry::score));
        for (Map.Entry<Long, Long> entry : scores.entrySet()) {
            minHeap.add(new LeaderboardEntry(entry.getKey(), entry.getValue()));
            if (minHeap.size() > k) minHeap.poll();
        }

        List<LeaderboardEntry> result = new ArrayList<>(minHeap);
        result.sort(Comparator.comparingLong(LeaderboardEntry::score).reversed());
        return result;
    }

    public void increment(String key, Long userId, long delta) {
        data.computeIfAbsent(key, k -> new ConcurrentHashMap<>())
                .merge(userId, delta, Long::sum);
    }
}