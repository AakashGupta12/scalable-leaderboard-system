package com.example.leaderboard.api;

import com.example.leaderboard.core.LeaderboardEntry;
import com.example.leaderboard.core.LeaderboardService;
import com.example.leaderboard.window.TimeWindowType;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/leaderboard")
public class LeaderboardController {

    private final LeaderboardService service;

    public LeaderboardController(LeaderboardService service) {
        this.service = service;
    }

    @PostMapping("/score")
    public void update(@RequestParam Long userId,
                       @RequestParam long delta,
                       @RequestParam TimeWindowType window,
                       @RequestParam(defaultValue = "redisTopK") String strategy) {
        service.updateScore(userId, delta, window, strategy);
    }

    @GetMapping("/top")
    public List<LeaderboardEntry> top(@RequestParam int k,
                                      @RequestParam TimeWindowType window,
                                      @RequestParam(defaultValue = "redisTopK") String strategy) {
        return service.topK(k, window, strategy);
    }
}
