package com.example.leaderboard.strategy;

import com.example.leaderboard.core.LeaderboardEntry;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * ApproximateTopKStrategy using Count-Min Sketch (simplified)
 * Good for extremely large leaderboards where exact ranking is not required
 */
@Component("approximateTopK")
public class ApproximateTopKStrategy implements TopKStrategy {

    // Map<key, CountMinSketch> for each leaderboard window
    private final Map<String, CountMinSketch> sketches = new ConcurrentHashMap<>();

    // Increment score in CMS
    public void increment(String key, long userId, long delta) {
        sketches.computeIfAbsent(key, k -> new CountMinSketch(0.001, 0.99))
                .add(userId, delta);
    }

    @Override
    public List<LeaderboardEntry> topK(String key, int k) {
        CountMinSketch cms = sketches.get(key);
        if (cms == null) return Collections.emptyList();

        // Since CMS does not store items, we need a side map of seen users
        Map<Long, Long> estimatedScores = cms.getItems();

        PriorityQueue<LeaderboardEntry> minHeap = new PriorityQueue<>(Comparator.comparingLong(LeaderboardEntry::score));
        for (Map.Entry<Long, Long> entry : estimatedScores.entrySet()) {
            minHeap.add(new LeaderboardEntry(entry.getKey(), entry.getValue()));
            if (minHeap.size() > k) minHeap.poll();
        }

        List<LeaderboardEntry> result = new ArrayList<>(minHeap);
        result.sort(Comparator.comparingLong(LeaderboardEntry::score).reversed());
        return result;
    }

    // Simple in-memory CMS
    static class CountMinSketch {
        private final double[][] table;
        private final int depth;
        private final int width;
        private final Random[] hashFunctions;
        private final Map<Long, Long> items; // store seen items for topK retrieval

        public CountMinSketch(double eps, double confidence) {
            this.width = (int) Math.ceil(Math.E / eps);
            this.depth = (int) Math.ceil(-Math.log(1 - confidence));
            table = new double[depth][width];
            hashFunctions = new Random[depth];
            items = new ConcurrentHashMap<>();
            for (int i = 0; i < depth; i++) hashFunctions[i] = new Random(i + 1);
        }

        public void add(long item, long count) {
            items.merge(item, count, Long::sum);
            for (int i = 0; i < depth; i++) {
                int hash = Math.abs((Long.hashCode(item) ^ hashFunctions[i].nextInt()) % width);
                table[i][hash] += count;
            }
        }

        public long estimate(long item) {
            long min = Long.MAX_VALUE;
            for (int i = 0; i < depth; i++) {
                int hash = Math.abs((Long.hashCode(item) ^ hashFunctions[i].nextInt()) % width);
                min = Math.min(min, (long) table[i][hash]);
            }
            return min;
        }

        public Map<Long, Long> getItems() {
            return items;
        }
    }
}
