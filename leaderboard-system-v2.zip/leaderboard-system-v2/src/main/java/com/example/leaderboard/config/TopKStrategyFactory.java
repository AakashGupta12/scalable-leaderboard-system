package com.example.leaderboard.config;

import com.example.leaderboard.strategy.TopKStrategy;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

@Component
public class TopKStrategyFactory {

    private final ApplicationContext context;

    public TopKStrategyFactory(ApplicationContext context) {
        this.context = context;
    }

    public TopKStrategy getStrategy(String name) {
        return (TopKStrategy) context.getBean(name);
    }
}
