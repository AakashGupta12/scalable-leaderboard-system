package com.example.leaderboard.core;

public record Rank(Long userId, long position, long score) {}
