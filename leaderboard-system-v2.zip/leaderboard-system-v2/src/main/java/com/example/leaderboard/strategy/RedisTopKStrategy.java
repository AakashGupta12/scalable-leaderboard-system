package com.example.leaderboard.strategy;

import com.example.leaderboard.core.LeaderboardEntry;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import java.util.List;

@Component("redisTopK")
public class RedisTopKStrategy implements TopKStrategy {

    private final StringRedisTemplate redis;

    public RedisTopKStrategy(StringRedisTemplate redis) {
        this.redis = redis;
    }

    @Override
    public List<LeaderboardEntry> topK(String key, int k) {
        return redis.opsForZSet()
                .reverseRangeWithScores(key, 0, k - 1)
                .stream()
                .map(e -> new LeaderboardEntry(
                        Long.valueOf(e.getValue()),
                        e.getScore().longValue()))
                .toList();
    }
}
