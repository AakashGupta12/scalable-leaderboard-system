package com.example.leaderboard.core;

import com.example.leaderboard.strategy.TopKStrategy;
import com.example.leaderboard.window.TimeWindowResolver;
import com.example.leaderboard.window.TimeWindowType;
import com.example.leaderboard.config.TopKStrategyFactory;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LeaderboardService {

    private final StringRedisTemplate redis;
    private final TopKStrategyFactory strategyFactory;

    public LeaderboardService(StringRedisTemplate redis, TopKStrategyFactory strategyFactory) {
        this.redis = redis;
        this.strategyFactory = strategyFactory;
    }

    public void updateScore(Long userId, long delta, TimeWindowType window, String strategyName) {
        String key = TimeWindowResolver.resolve(window);

        TopKStrategy strategy = strategyFactory.getStrategy(strategyName);

        if (strategy instanceof com.example.leaderboard.strategy.RedisTopKStrategy) {
            redis.opsForZSet().incrementScore(key, userId.toString(), delta);
        } else if (strategy instanceof com.example.leaderboard.strategy.InMemoryHeapTopKStrategy heap) {
            heap.increment(key, userId, delta);
        } else if (strategy instanceof com.example.leaderboard.strategy.ApproximateTopKStrategy approx) {
            approx.increment(key, userId, delta);
        }
        // DBTopKStrategy updates DB outside this method if needed
    }

    public List<LeaderboardEntry> topK(int k, TimeWindowType window, String strategyName) {
        String key = TimeWindowResolver.resolve(window);
        TopKStrategy strategy = strategyFactory.getStrategy(strategyName);
        return strategy.topK(key, k);
    }
}
