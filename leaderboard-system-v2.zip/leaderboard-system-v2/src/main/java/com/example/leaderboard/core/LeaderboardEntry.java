package com.example.leaderboard.core;

public record LeaderboardEntry(Long userId, long score) {}
