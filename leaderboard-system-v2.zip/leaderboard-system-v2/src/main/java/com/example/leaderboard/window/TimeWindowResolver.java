package com.example.leaderboard.window;

import java.time.LocalDate;
import java.time.YearMonth;
import java.time.temporal.WeekFields;

public class TimeWindowResolver {

    public static String resolve(TimeWindowType type) {
        return switch (type) {
            case DAILY -> "leaderboard:daily:" + LocalDate.now();
            case WEEKLY -> {
                var now = LocalDate.now();
                var wf = WeekFields.ISO;
                yield "leaderboard:weekly:" + now.getYear() + "-" + now.get(wf.weekOfWeekBasedYear());
            }
            case MONTHLY -> "leaderboard:monthly:" + YearMonth.now();
        };
    }
}
